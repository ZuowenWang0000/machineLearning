import sklearn as sk
import numpy
import matplotlib
import textblob
import pandas as pd

################################################################################
#loading dataset

trainData = open('data/train/r52-train-all-terms.txt').read()
label = []
text = []
for i, line in enumerate(trainData.split("\n")):
    content = line.split()

    label.append(content[0])
    text.append(content[1:])

train = pd.DataFrame()
train['text'] = text
train['label'] = label
#################################################################################

testData = open('data/test/r52-test-all-terms.txt').read()
testlabel = []
testtext = []
for i, line in enumerate(testData.split("\n")):
    content = line.split()
    testlabel.append(content[0])
    testtext.append(content[1:])

test = pd.DataFrame()
test['text'] = testtext
test['label'] = testlabel
#################################################################################
#encoding labels
# trainX, trainY = sk.model_selection.train_test_split(train['text'], train['label'])
# testX, testY = sk.model_selection.train_test_split(test['text'], test['label'])
trainX = train['text']
trainY = train['label']
testX = test['text']
testY = test['label']

encoder = sk.preprocessing.LabelEncoder()
trainY = encoder.fit_transform(trainY)
testY = encoder.fit_transform(testY)

#################################################################################
#Feature Engineering
#count vector, every row is a document, every column is a term,
#each entry represents the frequency count of that term in that document
CountVectorizer = sk.feature_extraction.text.CountVectorizer(analyzer=lambda doc:doc, lowercase = False, token_pattern=r'\w{1,}')
CountVectorizer.fit(pd.concat([trainX, testX]))

trainXcv = CountVectorizer.transform(trainX)
testXcv = CountVectorizer.transform(testX)

#################################################################################
# train a LDA model to extract features
from sklearn import decomposition, ensemble
LDAfeatureExtractor = decomposition.LatentDirichletAllocation(n_components=20, learning_method='batch', max_iter=2000)
TopicsX = LDAfeatureExtractor.fit_transform(trainXcv)
topicWord = LDAfeatureExtractor.components_
vocab = CountVectorizer.get_feature_names()

nTopWords = 10
topicSummaries = []
for i , topic_dist in enumerate(topicWord):
    topicWord = numpy.array(vocab)[numpy.argsort(topic_dist)][:-(nTopWords+1):-1]
    topicSummaries.append(' '.join(topicWord))

print(topicWord)
print(topicSummaries)



#train and validate   Naive Bayes
# from sklearn.naive_bayes import MultinomialNB
# NBclassifier = MultinomialNB()
# NBclassifier.fit(trainXcv, trainY)
# prediction = NBclassifier.predict(testXcv)
# acc = sk.metrics.accuracy_score(prediction, testY)
# print("Multinomial NB\t, accuracy on test dataset : " + str(acc))
# #################################################################################
# #train and validate    SVM
# from sklearn.svm import SVC
# SVCclassifier = SVC(C=10.0, kernel='rbf', degree=3, gamma='auto_deprecated', coef0=0.0,
#                     shrinking=True, probability=False, tol=0.0001, cache_size=200,
#                     class_weight=None, verbose=False, max_iter=-1, decision_function_shape='ovr',
#                     random_state=None)
# SVCclassifier.fit(trainXcv, trainY)
# prediction = SVCclassifier.predict(testXcv)
# acc = sk.metrics.accuracy_score(prediction, testY)
# print("SVC \t\t\t, accuracy on test dataset : " + str(acc))
#################################################################################
# #train and validate    linear svm
# from sklearn.svm import LinearSVC
# linearSVCclassifier = LinearSVC(C=1.0, class_weight=None, dual=True, fit_intercept=True,
#      intercept_scaling=1, loss='squared_hinge', max_iter=-1,
#      multi_class='crammer_singer', penalty='l2', random_state=0, tol=1e-05, verbose=0)
# linearSVCclassifier.fit(trainXcv, trainY)
# prediction = SVCclassifier.predict(testXcv)
# acc = sk.metrics.accuracy_score(prediction, testY)
# print("linearSVC \t\t\t, accuracy on test dataset : " + str(acc))

#################################################################################
# #train and validate    ANN
# from sklearn.neural_network import MLPClassifier
# annClassifier = MLPClassifier(solver='lbfgs', alpha=1e-5,
#                     hidden_layer_sizes=(1024), random_state=1, verbose = 2)
# annClassifier.fit(trainXcv, trainY)
# prediction = annClassifier.predict(testXcv)
# acc = sk.metrics.accuracy_score(prediction, testY)
# print("ANN \t\t\t, accuracy on test dataset : " + str(acc))



