import pandas

#loading dataset

trainData = open('data/train/r52-train-all-terms.txt').read()
label = []
text = []
for i, line in enumerate(trainData.split("\n")):
    content = line.split()
    label.append(content[0])
    text.append(content[1:])

train = pandas.DataFrame()
train['text'] = text
train['label'] = label

print(train['text'].size)
print(train['label'].size)
print(train['text'])
print(train['label'])